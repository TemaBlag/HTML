counter = 0;
var longBlink = function () {
  function blink(){
    $("h1").fadeOut(500).fadeIn(500);
    counter++;
  }
  return setInterval(blink, 1000);
}
if ( counter > 5){
  clearInterval (blikGo);
} 
var blikGo = longBlink();
 